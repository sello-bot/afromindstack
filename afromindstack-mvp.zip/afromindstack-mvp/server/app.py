import io, os
from datetime import datetime, timezone
from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_file
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

load_dotenv()
app = Flask(__name__, instance_relative_config=True)
os.makedirs(app.instance_path, exist_ok=True)
url = os.getenv("DATABASE_URL", "").strip()
if url.startswith("postgres://"): url = url.replace("postgres://", "postgresql+psycopg://", 1)
elif url.startswith("postgresql://") and "+psycopg" not in url: url = url.replace("postgresql://", "postgresql+psycopg://", 1)
app.config["SQLALCHEMY_DATABASE_URI"] = url or "sqlite:///" + os.path.join(app.instance_path, "afromindstack.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)
CORS(app, resources={r"/api/*": {"origins": "*"}})  # Restrict origins before production.

class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(160), nullable=False)
    company = db.Column(db.String(180), nullable=False)
    email = db.Column(db.String(254), nullable=False, default="")
    phone = db.Column(db.String(40), nullable=False, default="")
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))

@app.get("/api/health")
def health():
    return jsonify(status="ok", service="afromindstack-api", time=datetime.now(timezone.utc).isoformat())

@app.get("/api/clients")
def list_clients():
    return jsonify([{"id":c.id,"name":c.name,"company":c.company,"email":c.email,"phone":c.phone} for c in Client.query.order_by(Client.id.desc()).all()])

@app.post("/api/clients")
def create_client():
    data = request.get_json(silent=True) or {}
    name, company = str(data.get("name","")).strip(), str(data.get("company","")).strip()
    if not name or not company: return jsonify(error="name and company are required"), 400
    c = Client(name=name, company=company, email=str(data.get("email","")).strip(), phone=str(data.get("phone","")).strip())
    db.session.add(c); db.session.commit()
    return jsonify(id=c.id,name=c.name,company=c.company,email=c.email,phone=c.phone), 201

@app.delete("/api/clients/<int:client_id>")
def delete_client(client_id):
    c = db.session.get(Client, client_id)
    if c is None: return jsonify(error="client not found"), 404
    db.session.delete(c); db.session.commit()
    return jsonify(deleted=True)

@app.post("/api/pdf")
def generate_pdf():
    data = request.get_json(silent=True) or {}
    kind = str(data.get("kind","Invoice"))[:30]
    reference = str(data.get("reference","DRAFT"))[:60]
    client = str(data.get("client","Customer"))[:180]
    try: amount = max(0, float(data.get("amount",0)))
    except (TypeError, ValueError): return jsonify(error="amount must be numeric"), 400
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf,pagesize=A4,rightMargin=22*mm,leftMargin=22*mm,topMargin=22*mm,bottomMargin=22*mm)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="Brand",parent=styles["Title"],textColor=colors.HexColor("#4E8B13"),alignment=0))
    story=[Paragraph("AfromindStack",styles["Brand"]),Spacer(1,5*mm),Paragraph(kind.title(),styles["Heading1"]),Paragraph("Reference: "+reference,styles["Normal"]),Paragraph("Customer: "+client,styles["Normal"]),Spacer(1,8*mm)]
    table=Table([["Description","Amount (ZAR)"],[kind+" — "+reference,"R {:,.2f}".format(amount)]],colWidths=[110*mm,48*mm])
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#172017")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("GRID",(0,0),(-1,-1),.5,colors.HexColor("#DDE4D9")),("ALIGN",(1,0),(1,-1),"RIGHT"),("PADDING",(0,0),(-1,-1),10)]))
    story.extend([table,Spacer(1,8*mm),Paragraph("Starter template only. Add your registered business details and review applicable South African invoicing requirements before use.",styles["Italic"])])
    doc.build(story); buf.seek(0)
    return send_file(buf,mimetype="application/pdf",as_attachment=True,download_name=kind.lower()+"-"+reference.replace("/","-")+".pdf")

with app.app_context(): db.create_all()
if __name__ == "__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")),debug=os.getenv("FLASK_DEBUG","0")=="1")
